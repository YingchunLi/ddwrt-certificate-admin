import React from 'react';
import StepperApp from './StepperApp';

const App = () => (
  <div>
    <StepperApp />
  </div>
);

export default App;
